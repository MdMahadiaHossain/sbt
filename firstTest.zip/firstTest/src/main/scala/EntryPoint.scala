
object EntryPoint {
  def main(args: Array[String]): Unit = {
    println("Hello")
    val x = new Util
    x.show()
  }
}
