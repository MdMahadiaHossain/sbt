class Util {
 def show():Unit={
   println("method show(), accessing from project_1 . . . . ")
 }
}
