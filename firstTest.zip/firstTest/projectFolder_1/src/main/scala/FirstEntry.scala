object FirstEntry{
  def main(args: Array[String]): Unit = {
    println("project_2")
  }
}