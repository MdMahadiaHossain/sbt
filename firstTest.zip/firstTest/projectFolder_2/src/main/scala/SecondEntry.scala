object SecondEntry{
  def main(args: Array[String]): Unit = {
    println("project_2")
  }
}